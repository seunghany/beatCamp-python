def foo():
    print('Foo runs')
